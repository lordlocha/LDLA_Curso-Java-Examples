package es.gob.educacion.persistencia;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import es.gob.educacion.modelo.Producto;

@ManagedBean(name = "dao", eager = true)
@ApplicationScoped
public class ProductosDAO implements Serializable { //SIN SERIALIZABLE NO SE PODRÍA GUARDAR EN EL AMBITO.
	
	public Producto buscar(int id) {
		return new Producto(id, "Producto " + id, id*100);
	}
	
	public List<Producto> todos(){
		List<Producto> lista = new ArrayList<Producto>();
		
		for(int i=1; i<=10; i++){
			lista.add(new Producto(i, "Producto " + i, i*100));
		}
		
		return lista;
	}
	
	public boolean alta(Producto producto){
		return true;
	}
	
}
