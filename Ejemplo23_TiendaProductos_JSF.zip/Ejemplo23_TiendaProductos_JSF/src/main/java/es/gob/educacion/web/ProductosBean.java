package es.gob.educacion.web;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;

import es.gob.educacion.modelo.Producto;
import es.gob.educacion.persistencia.ProductosDAO;

@ManagedBean
@RequestScoped
public class ProductosBean {

	@ManagedProperty(value="#{dao}")
	private ProductosDAO dao;

	public List<Producto> consultarTodos() {
		return dao.todos();
	}
		
	public ProductosDAO getDao() {
		return dao;
	}

	public void setDao(ProductosDAO dao) {
		this.dao = dao;
	}
	
}
