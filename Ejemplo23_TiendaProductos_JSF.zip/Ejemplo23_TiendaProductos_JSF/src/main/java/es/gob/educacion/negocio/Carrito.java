package es.gob.educacion.negocio;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import es.gob.educacion.modelo.Producto;
import es.gob.educacion.persistencia.ProductosDAO;

@ManagedBean
@SessionScoped
public class Carrito implements Serializable {

	private List<Producto> contenido = new ArrayList<>();
	private double importe;
	
	@ManagedProperty(value="#{dao}")
	private ProductosDAO dao;
	
	public String agregarProducto(int id) {
		Producto encontrado = dao.buscar(id);
			
		//Agregar el contenido
		contenido.add(encontrado);
		
		//Incrementar el importe del carrito
		importe += encontrado.getPrecio();
		
		//Devolver el nombre de la vista
		return "mostrarCarrito";
	}

	public String sacarProducto(Producto producto) {
		Producto encontrado = null;
		for (Producto prod : contenido) {
			if (prod.getId() == producto.getId())
			{
				encontrado = prod;
				break;
			}	
		}
		
		importe -= encontrado.getPrecio();
		contenido.remove(encontrado);
		
		return "mostrarCarrito";
	}
	
	public List<Producto> getContenido() {
		return contenido;
	}

	public void setContenido(List<Producto> contenido) {
		this.contenido = contenido;
	}

	public double getImporte() {
		return importe;
	}

	public void setImporte(double importe) {
		this.importe = importe;
	}

	public ProductosDAO getDao() {
		return dao;
	}

	public void setDao(ProductosDAO dao) {
		this.dao = dao;
	}
	
	
}
